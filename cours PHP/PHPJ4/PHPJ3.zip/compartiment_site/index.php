
<?php 
include('inc/header.inc.php'); 
include('inc/nav.inc.php'); 
?>
        <main> <!-- Main : Contenu principal de la page-->
            <aside><!--Aside : Contenu secondaire -->

            </aside>
            <section> <!-- Section : Zone de contenu : titre, texte, regroupement thématique-->
                <div> <!-- Div : Zone supplémentaire de contenu-->
					
                </div>
                <span> <!-- Span : Zone supplémentaire de contenu-->

                </span>
                <article> <!-- Article : Zone supplémentaire de contenu-->

                </article>
            </section>
        </main>
<?php 
include('inc/footer.inc.php');
?>
      