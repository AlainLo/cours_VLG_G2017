<h1>Page 1</h1>
<a href="page2.php?article=jean&couleur=bleu&prix=10">Page2</a>

<!-- ?  article=jean  &  couleur=bleu  &   prix=10 -->