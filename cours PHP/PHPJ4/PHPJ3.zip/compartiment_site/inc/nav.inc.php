			<nav>
				<a href="index.php">Accueil</a>
				<a href="texte.php" class="activ">Textes</a>
				<a href="selecteurs.php">Selecteurs</a>
				<a href="images.php">Images</a>
				<a href="formulaire.php">Formulaires</a>
			</nav>