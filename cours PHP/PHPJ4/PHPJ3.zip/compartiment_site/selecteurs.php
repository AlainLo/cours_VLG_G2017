<?php 
include('inc/header.inc.php'); 
include('inc/nav.inc.php'); 
?>

        <main>
            <h2>Selecteurs</h2>
                <section class="select">
                    <h3> Les selecteurs </h3>
                        <p>Texte n°1</p>
                        <p>Texte n°2</p>
                        <p>Texte n°3</p>
                        <p>Texte n°4</p>
                        <p>Texte n°5</p>
                        <p>Texte n°6</p>
                        <p>Texte n°7</p>
                        <p>Texte n°8</p>
                        <p>Texte n°9</p>
                        <p>Texte n°10</p>

                        <div class="zoneA"> Zone A </div>
                        <div class="zoneB"> Zone B Zone B <span class ="couleurBleu">texte</span> Zone B Zone B </div>
                        <div id="zoneC"> Zone C </div>
                        <div id="zoneD"> Zone <span> D </span></div>

                </section>


        </main>

    <?php 
include('inc/footer.inc.php');
?>
      