<?php 
include('inc/header.inc.php'); 
include('inc/nav.inc.php'); 
?>

        <main>
            <h2>Texte</h2>
            <section>
                <h3>Titre de la première section</h3>
                <blockquote><i class="fa fa-quote-left" aria-hidden="true"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit. <i class="fa fa-quote-right" aria-hidden="true"></i></blockquote>
                <p><strong>Sed volutpat pharetra pellentesque. Sed mollis eleifend mauris quis commodo.</strong>  Sed molestie rhoncus nibh. Proin id felis aliquet, finibus neque molestie, mattis dolor. Donec porta risus tellus, a fermentum massa fermentum sit amet. Maecenas eget risus sed elit egestas fringilla sed vitae diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi pulvinar, mi vitae congue rutrum, ex velit vulputate purus, non pulvinar nisl elit non nisl. Mauris vehicula neque ac ex auctor mattis. Donec tempus metus sed turpis fringilla ultrices. </p>
            </section>

            <section class="roboto">
                <h3>Titre de la deuxième section</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed volutpat pharetra pellentesque. Sed mollis eleifend mauris quis commodo. Sed molestie rhoncus nibh. Proin id felis aliquet, finibus neque molestie, mattis dolor. Donec porta risus tellus, a fermentum massa fermentum sit amet. Maecenas eget risus sed elit egestas fringilla sed vitae diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi pulvinar, mi vitae congue rutrum, ex velit vulputate purus, non pulvinar nisl elit non nisl. Mauris vehicula neque ac ex auctor mattis. Donec tempus metus sed turpis fringilla ultrices.</p>
            </section>
        </main>
    <?php 
include('inc/footer.inc.php');
?>
      
