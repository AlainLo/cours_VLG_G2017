  <a href="#logo"><button type="button"><i class="fa fa-arrow-circle-up" aria-hidden="true"></i></button></a>

        <footer> <!--Footer : Zone du bas, ex: les liens administratifs, mentions l�gales, plan du site...-->
			(c)<?php echo date('Y'); ?> - PoleS
        </footer>
    </body>

</html>
